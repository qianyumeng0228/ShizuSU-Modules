#!/bin/sh
PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:$PATH
SUSFS_BIN=/data/adb/ksu/bin/ksu_susfs
. $MODPATH/utils.sh
PERSISTENT_DIR=/data/adb/bindhosts

export MODULE_HOT_INSTALL_REQUEST="true"
export MODULE_HOT_RUN_SCRIPT="hotinstall.sh"

# grab own info (version)
versionCode=$(grep versionCode "$MODPATH/module.prop" | sed 's/versionCode=//g' )

echo "[+] bindhosts v$versionCode "
echo "[%] customize.sh "

# [ShizuSU 适配] 原版 detect_key_press 使用 < <() 进程替换监听音量键，
# toybox sh 不支持该语法导致安装失败。此处直接跳过 BindHosts-app 安装
# （功能不受影响：WebUI 仍可管理 hosts 规则）。
# [ShizuSU 适配] 跳过 BindHosts-app 安装询问（原逻辑依赖音量键检测）。
echo "[+] BindHosts-app not installed, skipped (use built-in WebUI)"
# persistence
[ ! -d $PERSISTENT_DIR ] && mkdir -p $PERSISTENT_DIR
# make our hosts file dir
mkdir -p "$MODPATH/system/etc"

# set permissions to bindhosts.sh
busybox chmod +x "$MODPATH/bindhosts.sh"
busybox chmod +x "$MODPATH/bindhosts-app.sh"
# symlink bindhosts to manager path
# for ez termux usage
manager_paths="/data/adb/ap/bin /data/adb/ksu/bin"
for i in $manager_paths; do
	if [ -d "$i" ]; then
		echo "[+] creating symlink in $i"
		ln -sf /data/adb/modules/bindhosts/bindhosts.sh "$i/bindhosts"
	fi
done

# check for other systemless hosts modules and disable them
disable_hosts_modules_verbose=1
disable_hosts_modules

# warn about highly breaking modules
# just warn and tell user to uninstall it
# we would still proceed to install
# lets make the user wait for say 5 seconds
bad_module="HideMyRoot"
for i in $bad_module; do
	if [ -d "/data/adb/modules/$i" ] ; then
		echo "[!] 🚨 possible confliciting module found!"
		echo "[!] ⚠️ $i "
		echo "[!] 📢 uninstall for a flawless operation"
		echo "[!] ‼️ you have been warned"
		sleep 5
	fi
done

# copy our old hosts file
if [ -f /data/adb/modules/bindhosts/system/etc/hosts ] ; then
	echo "[+] migrating hosts file "
	cat /data/adb/modules/bindhosts/system/etc/hosts > "$MODPATH/system/etc/hosts"
fi

# normal flow for persistence
# move over our files, remove after
files="blacklist.txt custom.txt sources.txt whitelist.txt sources_whitelist.txt"
for i in $files ; do
	if [ ! -f "/data/adb/bindhosts/$i" ] ; then
		cat "$MODPATH/$i" > "$PERSISTENT_DIR/$i"
	fi
	rm "$MODPATH/$i"
done

# webui custom css config
if [ ! -d "$PERSISTENT_DIR/.webui_config" ] || [ ! -f "$PERSISTENT_DIR/.webui_config/custom.css" ]; then
	mkdir -p "$PERSISTENT_DIR/.webui_config"
	mv "$MODPATH/custom.css" "$PERSISTENT_DIR/.webui_config/custom.css"
else
	rm "$MODPATH/custom.css"
fi

# if hosts file empty or just comments
# just copy real hosts file over
grep -qv "#" "$MODPATH/system/etc/hosts" > /dev/null 2>&1 || {
	echo "[+] creating hosts file"
	cat /system/etc/hosts > "$MODPATH/system/etc/hosts"
	printf "127.0.0.1 localhost\n::1 localhost\n" >> "$MODPATH/system/etc/hosts"
}

# set permissions always
hosts_set_perm "$MODPATH/system/etc/hosts"

# EOF
