MODDIR=${0%/*}

PROPS="$(awk '/^persist\./ {sub(/=.*/, ""); print}' "$MODDIR/system.prop")"

for prop in $PROPS; do
	resetprop -p --delete "$prop"
done

chattr -i /data/vendor/thermal /data/vendor/thermal/config /data/vendor/thermal/config/*
rm -rf /data/vendor/thermal/config/*
rm -rf /sdcard/Android/Eclipse