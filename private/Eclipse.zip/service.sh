#!/system/bin/sh

MODDIR=${0%/*}

wait_until_login() {
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        sleep 1
    done

    until [ -d "/data/data/android" ]; do
        sleep 1
    done
    
    sleep 60
}

lock_val() {
    find "$2" -type f | while read -r file; do
        file="$(realpath "$file")"
        umount "$file"
        chown root:root "$file"
        chmod 0644 "$file"
        echo "$1" >"$file"
        chmod 0444 "$file"
    done
}

wait_until_login
killall -15 Asphyxia; nohup $MODDIR/Asphyxia > /dev/null 2>&1 &