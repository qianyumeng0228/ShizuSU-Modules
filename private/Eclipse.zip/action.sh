#!/system/bin/sh

MODDIR=${0%/*}
CONFIG="/data/vendor/thermal/config"

key_click() {
    while true; do
        sleep 0.5
        keyInfo=$(getevent -qlc 1 | grep KEY_VOLUME)
        if [ -n "$keyInfo" ]; then
            case "$keyInfo" in
                *KEY_VOLUMEUP*) return 0 ;;
                *) return 1 ;;
            esac
        fi
    done
}

echo "*********************************"
echo "-     请选择温控模式："
echo ""
echo "      音量↑:[夏日限定]│[深度定制]"
echo "      音量↓:[极致性能]│[丧心病狂]"

if key_click; then
    COLD_PRO=1
else
    COLD_PRO=0
fi

if [ "$COLD_PRO" -eq 1 ]; then
    echo ""
    echo "      音量↑:[夏日限定]"
    echo "      音量↓:[深度定制]"

    if key_click; then
        MODE="cool"
        DISPLAY="夏日限定"
    else
        MODE="pro"
        DISPLAY="深度定制"
    fi
else
    echo ""
    echo "      音量↑:[极致性能]"
    echo "      音量↓:[丧心病狂]"

    if key_click; then
        MODE="extreme"
        DISPLAY="极致性能"
    else
        MODE="danger"
        DISPLAY="丧心病狂"
    fi
fi

echo ""
echo "-     您选择了 [$DISPLAY]🤔"
echo "*********************************"

# Write new mode to files.ini, thermal.sh will read it
chattr -i "$CONFIG"/* 2>/dev/null
echo "$MODE" > "$CONFIG/files.ini"

sh "$MODDIR/thermal.sh"

echo "- 成功更改模式😋"