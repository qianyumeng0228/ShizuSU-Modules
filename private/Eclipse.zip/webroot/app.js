const CONFIG_PATH = "/sdcard/Android/Eclipse/Asphyxia.toml";
const ALT_CONFIG_PATH = "/storage/emulated/0/Android/Eclipse/Asphyxia.toml";

const state = { global: {}, limits: {}, apps: {} };
const ui = { appOpen: {} };

let parseBlocked = false;
const message = document.getElementById("message");

const $ = id => document.getElementById(id);

function setMessage(text, type = "") {
  if (!message) return;
  message.textContent = text;
  message.className = "message " + type;
}

function shellQuote(s) {
  return "'" + String(s).replaceAll("'", "'\\''") + "'";
}

function enc(s) {
  return encodeURIComponent(String(s));
}

function dec(s) {
  return decodeURIComponent(String(s || ""));
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

async function exec(cmd) {
  if (!window.ksu || typeof window.ksu.exec !== "function") {
    throw new Error("KernelSU WebUI API 不可用");
  }

  const r = await window.ksu.exec(cmd);

  if (typeof r === "string") {
    return { errno: 0, stdout: r, stderr: "" };
  }

  return {
    errno: Number(r?.errno ?? r?.code ?? 0),
    stdout: String(r?.stdout ?? r?.out ?? r?.output ?? r?.result ?? ""),
    stderr: String(r?.stderr ?? r?.error ?? "")
  };
}

function toBase64(text) {
  const bytes = new TextEncoder().encode(text);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}

function fromBase64(b64) {
  const clean = String(b64 || "").replace(/\s+/g, "");
  if (!clean) return "";

  const bin = atob(clean);
  const bytes = new Uint8Array(bin.length);

  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }

  return new TextDecoder().decode(bytes);
}

function resetState() {
  state.global = {};
  state.limits = {};
  state.apps = {};
}

function makeRule(value, disabled = false) {
  return { value: String(value ?? ""), disabled: !!disabled };
}

function ensureApp(pkg) {
  pkg = String(pkg || "").trim();
  if (!pkg) return null;

  if (!state.apps[pkg]) {
    state.apps[pkg] = { config: {}, default: {} };
  }

  return state.apps[pkg];
}

function removeBom(text) {
  return String(text || "").replace(/^\uFEFF/, "");
}

function stripInlineComment(line) {
  let q = false, e = false;

  for (let i = 0; i < line.length; i++) {
    const c = line[i];

    if (e) {
      e = false;
      continue;
    }

    if (q && c === "\\") {
      e = true;
      continue;
    }

    if (c === '"') {
      q = !q;
      continue;
    }

    if (!q && c === "#") return line.slice(0, i);
  }

  return line;
}

function unescapeStr(s) {
  let out = "", e = false;

  for (let i = 0; i < s.length; i++) {
    const c = s[i];

    if (e) {
      out += c === "n" ? "\n" :
             c === "r" ? "\r" :
             c === "t" ? "\t" :
             c === "\\" ? "\\" :
             c === '"' ? '"' : c;
      e = false;
      continue;
    }

    if (c === "\\") {
      e = true;
      continue;
    }

    out += c;
  }

  return out;
}

function escapeStr(s) {
  return String(s)
    .replaceAll("\\", "\\\\")
    .replaceAll('"', '\\"')
    .replaceAll("\n", "\\n")
    .replaceAll("\r", "\\r")
    .replaceAll("\t", "\\t");
}

function parseTomlString(raw) {
  const s = String(raw || "").trim();

  if (s.length >= 2 && s.startsWith('"') && s.endsWith('"')) {
    return unescapeStr(s.slice(1, -1));
  }

  if (s.length >= 2 && s.startsWith("'") && s.endsWith("'")) {
    return s.slice(1, -1);
  }

  return s;
}

function parseSection(line) {
  const m = line.match(/^\[\s*(.*?)\s*\]$/);
  if (!m) return null;

  const name = m[1].trim();

  if (name === "config") return { type: "global", pkg: "" };
  if (name === "limits") return { type: "limits", pkg: "" };

  if (name.startsWith("config.")) {
    return { type: "app-config", pkg: parseTomlString(name.slice(7)) };
  }

  if (name.startsWith("default.")) {
    return { type: "app-default", pkg: parseTomlString(name.slice(8)) };
  }

  if (name.startsWith("APP.")) {
    return { type: "app-config", pkg: parseTomlString(name.slice(4)) };
  }

  return null;
}

function findEq(line) {
  let q = false, e = false;

  for (let i = 0; i < line.length; i++) {
    const c = line[i];

    if (e) {
      e = false;
      continue;
    }

    if (q && c === "\\") {
      e = true;
      continue;
    }

    if (c === '"') {
      q = !q;
      continue;
    }

    if (!q && c === "=") return i;
  }

  return -1;
}

function parseKV(line) {
  const p = findEq(line);
  if (p < 0) return null;

  const left = line.slice(0, p).trim();
  const right = line.slice(p + 1).trim();

  if (!left) return null;

  let key;

  if (left.startsWith('"') && left.endsWith('"')) {
    key = unescapeStr(left.slice(1, -1));
  } else if (left.startsWith("'") && left.endsWith("'")) {
    key = left.slice(1, -1);
  } else {
    key = left;
  }

  if (!key) return null;

  return [key, parseTomlString(right)];
}

function parseLine(raw) {
  const t = String(raw || "").trim();

  if (!t) return { type: "empty" };

  if (t.startsWith("#")) {
    const body = t.slice(1).trim();
    const kv = parseKV(body);

    if (kv) {
      return { type: "kv", key: kv[0], value: kv[1], disabled: true };
    }

    return { type: "comment" };
  }

  const clean = stripInlineComment(raw).trim();
  if (!clean) return { type: "comment" };

  const sec = parseSection(clean);
  if (sec) return { type: "section", section: sec };

  const kv = parseKV(clean);
  if (kv) return { type: "kv", key: kv[0], value: kv[1], disabled: false };

  return { type: "unknown" };
}

function parseToml(text) {
  resetState();
  text = removeBom(text);

  let section = "", pkg = "";

  for (const raw of String(text || "").split(/\r?\n/)) {
    const item = parseLine(raw);

    if (item.type === "section") {
      section = item.section.type;
      pkg = item.section.pkg || "";

      if ((section === "app-config" || section === "app-default") && pkg) {
        ensureApp(pkg);
      }

      continue;
    }

    if (item.type !== "kv") continue;

    const rule = makeRule(item.value, item.disabled);

    if (section === "global") {
      state.global[item.key] = rule;
    } else if (section === "limits") {
      state.limits[item.key] = rule;
    } else if (section === "app-config" && pkg) {
      const app = ensureApp(pkg);
      if (app) app.config[item.key] = rule;
    } else if (section === "app-default" && pkg) {
      const app = ensureApp(pkg);
      if (app) app.default[item.key] = rule;
    }
  }
}

function countState() {
  let n = Object.keys(state.global).length + Object.keys(state.limits).length;

  for (const app of Object.values(state.apps)) {
    n += Object.keys(app.config).length + Object.keys(app.default).length;
  }

  return n;
}

function fmtPkg(pkg) {
  return /^[A-Za-z0-9_.]+$/.test(pkg) ? pkg : `"${escapeStr(pkg)}"`;
}

function ruleLine(path, rule) {
  const line = `"${escapeStr(path)}" = "${escapeStr(rule.value)}"`;
  return rule.disabled ? `# ${line}` : line;
}

function serializeToml() {
  const out = [];

  if (Object.keys(state.limits).length) {
    out.push("[limits]");
    for (const [p, r] of Object.entries(state.limits)) out.push(ruleLine(p, r));
    out.push("");
  }

  if (Object.keys(state.global).length) {
    out.push("[config]");
    for (const [p, r] of Object.entries(state.global)) out.push(ruleLine(p, r));
    out.push("");
  }

  for (const [pkg, app] of Object.entries(state.apps)) {
    if (Object.keys(app.config).length) {
      out.push(`[config.${fmtPkg(pkg)}]`);
      for (const [p, r] of Object.entries(app.config)) out.push(ruleLine(p, r));
      out.push("");
    }

    if (Object.keys(app.default).length) {
      out.push(`[default.${fmtPkg(pkg)}]`);
      for (const [p, r] of Object.entries(app.default)) out.push(ruleLine(p, r));
      out.push("");
    }
  }

  return out.join("\n").trim() + "\n";
}

async function readConfigText() {
  const cmd =
    `if [ -f ${shellQuote(CONFIG_PATH)} ]; then ` +
    `base64 ${shellQuote(CONFIG_PATH)} | tr -d '\\n'; ` +
    `elif [ -f ${shellQuote(ALT_CONFIG_PATH)} ]; then ` +
    `base64 ${shellQuote(ALT_CONFIG_PATH)} | tr -d '\\n'; fi`;

  const r = await exec(cmd);
  return r.errno === 0 ? fromBase64(r.stdout || "") : "";
}

async function loadConfig() {
  try {
    setMessage("正在读取配置...");
    parseBlocked = false;

    const text = await readConfigText();

    parseToml(text);
    render();

    const n = countState();

    if (!text.trim()) {
      setMessage("配置为空或不存在");
    } else if (n === 0) {
      parseBlocked = true;
      setMessage("已读取文件，但未解析到有效配置。为避免覆盖，已禁止保存。", "err");
    } else {
      setMessage("配置已读取", "ok");
    }
  } catch (e) {
    resetState();
    render();
    parseBlocked = true;
    setMessage(e.message || "读取失败", "err");
  }
}

async function saveConfig() {
  try {
    if (parseBlocked) {
      setMessage("当前配置未成功解析，已阻止保存，避免覆盖原文件。", "err");
      return;
    }

    const dir = CONFIG_PATH.substring(0, CONFIG_PATH.lastIndexOf("/"));
    const data = toBase64(serializeToml());

    setMessage("正在保存...");

    const cmd =
      `mkdir -p ${shellQuote(dir)} && ` +
      `printf '%s' ${shellQuote(data)} | base64 -d > ${shellQuote(CONFIG_PATH)} && ` +
      `chmod 0644 ${shellQuote(CONFIG_PATH)}`;

    const r = await exec(cmd);

    if (r.errno !== 0) throw new Error(r.stderr || "保存失败");

    render();
    setMessage("保存成功", "ok");
  } catch (e) {
    setMessage(e.message || "保存失败", "err");
  }
}

function getSearch(id) {
  return String($(id)?.value || "").trim().toLowerCase();
}

function shortPath(path) {
  const s = String(path);

  if (s.length <= 42) {
    return s;
  }

  const parts = s.split("/").filter(Boolean);

  if (parts.length >= 5) {
    return "/" + parts[0] + "/.../" + parts.slice(-3).join("/");
  }

  return s.slice(0, 20) + "..." + s.slice(-20);
}

function matchRule(path, rule, key) {
  if (!key) return true;
  return String(path).toLowerCase().includes(key) || String(rule.value).toLowerCase().includes(key);
}

function appRuleCount(app) {
  return Object.keys(app.config).length + Object.keys(app.default).length;
}

function appMatches(pkg, app, key) {
  if (!key) return true;
  if (pkg.toLowerCase().includes(key)) return true;

  for (const [p, r] of Object.entries(app.config)) if (matchRule(p, r, key)) return true;
  for (const [p, r] of Object.entries(app.default)) if (matchRule(p, r, key)) return true;

  return false;
}

function switchTab(name) {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));

  const t = $("view-" + name);
  if (t) t.classList.add("active");
}

function render() {
  renderRules("globalList", state.global, "global", "globalSearch", "暂无全局配置");
  renderRules("limitsList", state.limits, "limits", "limitsSearch", "暂无权限设置");
  renderApps();

  if ($("globalCount")) $("globalCount").textContent = `${Object.keys(state.global).length} 项`;
  if ($("limitsCount")) $("limitsCount").textContent = `${Object.keys(state.limits).length} 项`;
  if ($("appCount")) $("appCount").textContent = `${Object.keys(state.apps).length} 个应用`;
}

function renderRules(id, data, scope, searchId, emptyText) {
  const root = $(id);
  if (!root) return;

  const key = getSearch(searchId);
  const entries = Object.entries(data).filter(([p, r]) => matchRule(p, r, key));

  if (!entries.length) {
    root.innerHTML = `<div class="empty">${emptyText}</div>`;
    return;
  }

  root.innerHTML = entries.map(([p, r]) => `
    <div class="rule ${r.disabled ? "disabled" : ""}">
      <div class="rule-main">
        <div class="path" title="${escapeHtml(p)}">
          ${escapeHtml(shortPath(p))}
          ${r.disabled ? `<span class="badge">已禁用</span>` : ""}
        </div>
        <div class="value">值：<span>${escapeHtml(r.value)}</span></div>
      </div>
      <div class="rule-actions">
        <button class="btn small light js-edit-rule" data-scope="${scope}" data-path="${enc(p)}">编辑</button>
        <button class="btn small warn js-toggle-rule" data-scope="${scope}" data-path="${enc(p)}">${r.disabled ? "启用" : "禁用"}</button>
        <button class="btn small red js-delete-rule" data-scope="${scope}" data-path="${enc(p)}">删除</button>
      </div>
    </div>
  `).join("");
}

function renderApps() {
  const root = $("appList");
  if (!root) return;

  const key = getSearch("appSearch");
  const entries = Object.entries(state.apps).filter(([pkg, app]) => appMatches(pkg, app, key));

  if (!entries.length) {
    root.innerHTML = `<div class="empty">暂无应用配置</div>`;
    return;
  }

  root.innerHTML = entries.map(([pkg, app]) => {
    const open = ui.appOpen[pkg] ? "open" : "";
    const count = appRuleCount(app);

    return `
      <div class="app-card ${open}">
        <div class="app-title">
          <div>
            <h3>${escapeHtml(pkg)}</h3>
            <div class="app-meta">${count} 项配置</div>
          </div>
          <div class="rule-actions">
            <button class="btn small light js-toggle-app" data-pkg="${enc(pkg)}">${open ? "收起" : "展开"}</button>
            <button class="btn small red js-delete-app" data-pkg="${enc(pkg)}">删除</button>
          </div>
        </div>

        <div class="app-body">
          <div class="subsection">
            <div class="subsection-head">
              <div>
                <h4>前台配置</h4>
                <p>[config.${escapeHtml(pkg)}]</p>
              </div>
              <button class="btn small light js-add-app-rule" data-pkg="${enc(pkg)}" data-kind="config">添加</button>
            </div>
            <div class="list">${renderAppRuleHtml(pkg, app.config, "config", "暂无前台配置")}</div>
          </div>

          <div class="subsection">
            <div class="subsection-head">
              <div>
                <h4>退出恢复</h4>
                <p>[default.${escapeHtml(pkg)}]</p>
              </div>
              <button class="btn small light js-add-app-rule" data-pkg="${enc(pkg)}" data-kind="default">添加</button>
            </div>
            <div class="list">${renderAppRuleHtml(pkg, app.default, "default", "暂无恢复配置")}</div>
          </div>
        </div>
      </div>
    `;
  }).join("");
}

function renderAppRuleHtml(pkg, data, kind, emptyText) {
  const key = getSearch("appSearch");
  const entries = Object.entries(data).filter(([p, r]) => matchRule(p, r, key));

  if (!entries.length) return `<div class="empty">${emptyText}</div>`;

  return entries.map(([p, r]) => `
    <div class="rule ${r.disabled ? "disabled" : ""}">
      <div class="rule-main">
        <div class="path" title="${escapeHtml(p)}">
          ${escapeHtml(shortPath(p))}
          ${r.disabled ? `<span class="badge">已禁用</span>` : ""}
        </div>
        <div class="value">值：<span>${escapeHtml(r.value)}</span></div>
      </div>
      <div class="rule-actions">
        <button class="btn small light js-edit-app-rule" data-pkg="${enc(pkg)}" data-kind="${kind}" data-path="${enc(p)}">编辑</button>
        <button class="btn small warn js-toggle-app-rule" data-pkg="${enc(pkg)}" data-kind="${kind}" data-path="${enc(p)}">${r.disabled ? "启用" : "禁用"}</button>
        <button class="btn small red js-delete-app-rule" data-pkg="${enc(pkg)}" data-kind="${kind}" data-path="${enc(p)}">删除</button>
      </div>
    </div>
  `).join("");
}

async function askRule(oldPath = "", oldValue = "") {
  const path = prompt("请输入路径", String(oldPath ?? ""));
  if (path === null) return null;

  const cleanPath = path.trim();
  if (!cleanPath) return null;

  await sleep(120);

  const value = prompt("请输入值", String(oldValue ?? ""));
  if (value === null) return null;

  return [cleanPath, value];
}

async function detectWaltPolicies() {
  const cmd =
    `for p in /sys/devices/system/cpu/cpufreq/policy*; do ` +
    `[ -d "$p/walt" ] || continue; ` +
    `[ -e "$p/walt/up_rate_limit_us" ] || continue; ` +
    `[ -e "$p/walt/down_rate_limit_us" ] || continue; ` +
    `basename "$p"; done`;

  const r = await exec(cmd);
  if (r.errno !== 0) return [];

  return [...new Set(String(r.stdout || "")
    .split(/\s+/)
    .map(s => s.trim())
    .filter(s => /^policy[0-9]+$/.test(s)))]
    .sort((a, b) => Number(a.replace("policy", "")) - Number(b.replace("policy", "")));
}

async function addGlobalPreset() {
  parseBlocked = false;

  state.global["/sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq"] = makeRule("0");

  let policies = [];

  try {
    policies = await detectWaltPolicies();
  } catch (_) {
    policies = [];
  }

  if (policies.length) {
    for (const p of policies) {
      const base = `/sys/devices/system/cpu/cpufreq/${p}/walt`;
      state.global[`${base}/down_rate_limit_us`] = makeRule("1000");
      state.global[`${base}/up_rate_limit_us`] = makeRule("1000");
    }

    setMessage(`已添加全局预设，识别到 ${policies.length} 个 WALT policy`, "ok");
  } else {
    setMessage("未识别到 WALT，仅添加 scaling_min_freq 预设", "ok");
  }

  render();
}

function addLimitsPreset() {
  parseBlocked = false;
  state.limits["/data/system/mcd/df"] = makeRule("000");
  setMessage("已添加权限预设", "ok");
  render();
}

async function addGlobalRule() {
  parseBlocked = false;

  const r = await askRule("", "");
  if (!r) return;

  state.global[r[0]] = makeRule(r[1]);
  render();
}

async function addLimitRule() {
  parseBlocked = false;

  const r = await askRule("", "000");
  if (!r) return;

  state.limits[r[0]] = makeRule(r[1]);
  render();
}

function addApp() {
  parseBlocked = false;

  const pkg = prompt("请输入应用包名，例如 com.miHoYo.Yuanshen", "");
  if (!pkg) return;

  const clean = pkg.trim();
  if (!clean) return;

  ensureApp(clean);
  ui.appOpen[clean] = true;
  render();
}

document.addEventListener("click", async e => {
  const t = e.target;
  if (!(t instanceof HTMLElement)) return;

  if (t.classList.contains("js-toggle-app")) {
    const pkg = dec(t.dataset.pkg);
    ui.appOpen[pkg] = !ui.appOpen[pkg];
    render();
    return;
  }

  if (t.classList.contains("js-edit-rule")) {
    parseBlocked = false;

    const scope = t.dataset.scope;
    const path = dec(t.dataset.path);
    const table = scope === "limits" ? state.limits : state.global;
    const old = table[path];

    const r = await askRule(path, old?.value ?? "");
    if (!r) return;

    if (r[0] !== path) delete table[path];
    table[r[0]] = makeRule(r[1], old?.disabled ?? false);
    render();
    return;
  }

  if (t.classList.contains("js-toggle-rule")) {
    parseBlocked = false;

    const table = t.dataset.scope === "limits" ? state.limits : state.global;
    const path = dec(t.dataset.path);

    if (table[path]) table[path].disabled = !table[path].disabled;
    render();
    return;
  }

  if (t.classList.contains("js-delete-rule")) {
    parseBlocked = false;

    const table = t.dataset.scope === "limits" ? state.limits : state.global;
    const path = dec(t.dataset.path);

    if (!confirm("确定删除这条配置？")) return;

    delete table[path];
    render();
    return;
  }

  if (t.classList.contains("js-delete-app")) {
    parseBlocked = false;

    const pkg = dec(t.dataset.pkg);

    if (!confirm(`删除应用配置：${pkg}？`)) return;

    delete state.apps[pkg];
    delete ui.appOpen[pkg];
    render();
    return;
  }

  if (t.classList.contains("js-add-app-rule")) {
    parseBlocked = false;

    const pkg = dec(t.dataset.pkg);
    const kind = t.dataset.kind;

    const r = await askRule("", "");
    if (!r) return;

    const app = ensureApp(pkg);
    if (!app) return;

    const table = kind === "default" ? app.default : app.config;
    table[r[0]] = makeRule(r[1]);
    ui.appOpen[pkg] = true;
    render();
    return;
  }

  if (t.classList.contains("js-edit-app-rule")) {
    parseBlocked = false;

    const pkg = dec(t.dataset.pkg);
    const kind = t.dataset.kind;
    const path = dec(t.dataset.path);
    const app = ensureApp(pkg);

    if (!app) return;

    const table = kind === "default" ? app.default : app.config;
    const old = table[path];

    const r = await askRule(path, old?.value ?? "");
    if (!r) return;

    if (r[0] !== path) delete table[path];
    table[r[0]] = makeRule(r[1], old?.disabled ?? false);
    ui.appOpen[pkg] = true;
    render();
    return;
  }

  if (t.classList.contains("js-toggle-app-rule")) {
    parseBlocked = false;

    const pkg = dec(t.dataset.pkg);
    const kind = t.dataset.kind;
    const path = dec(t.dataset.path);
    const app = ensureApp(pkg);

    if (!app) return;

    const table = kind === "default" ? app.default : app.config;

    if (table[path]) table[path].disabled = !table[path].disabled;

    ui.appOpen[pkg] = true;
    render();
    return;
  }

  if (t.classList.contains("js-delete-app-rule")) {
    parseBlocked = false;

    const pkg = dec(t.dataset.pkg);
    const kind = t.dataset.kind;
    const path = dec(t.dataset.path);
    const app = ensureApp(pkg);

    if (!app) return;
    if (!confirm("确定删除这条配置？")) return;

    const table = kind === "default" ? app.default : app.config;
    delete table[path];
    ui.appOpen[pkg] = true;
    render();
  }
});

loadConfig();