#!/system/bin/sh

MODDIR=${0%/*}
DEVICE=$(getprop ro.product.device)
thermal_dir="/data/vendor/thermal"
CONFIG="$thermal_dir/config"
MODULE_PROP="$MODDIR/module.prop"

# Read mode from current files.ini
MODE=$(cat "$CONFIG/files.ini" 2>/dev/null | tr -d '[:space:]')
[ -z "$MODE" ] && MODE="cool"

chattr -i "$thermal_dir" "$CONFIG" "$CONFIG"/* 2>/dev/null
rm -rf "$CONFIG"/*

if [ -d "$MODDIR/$DEVICE/$MODE" ]; then
    cp -f "$MODDIR/$DEVICE/$MODE/"* "$CONFIG"
fi

chmod -R 0771 "$thermal_dir"
chown -R root:system "$CONFIG" 2>/dev/null
chown root:system "$thermal_dir/decrypt.txt" 2>/dev/null
chown system:system "$thermal_dir/report.dump" 2>/dev/null
chown system:system "$thermal_dir/thermal-global-mode" 2>/dev/null
chown system:system "$thermal_dir/thermal.dump" 2>/dev/null
restorecon -DFR "$thermal_dir" 2>/dev/null

chattr +i "$CONFIG"/* 2>/dev/null

# Update module.prop based on files.ini
INI="$CONFIG/files.ini"
if [ -f "$INI" ]; then
    INI_MODE=$(cat "$INI" | tr -d '[:space:]')
    case "$INI_MODE" in
        cool)    DISPLAY="夏日限定🥰" ;;
        pro)     DISPLAY="深度定制🥰" ;;
        extreme) DISPLAY="极致性能🥰" ;;
        danger)  DISPLAY="丧心病狂😡" ;;
        *)       DISPLAY="$INI_MODE" ;;
    esac

    if grep -q "当前温控模式：" "$MODULE_PROP"; then
        sed -i "s/当前温控模式：[^]]*/当前温控模式：${DISPLAY}/" "$MODULE_PROP"
    else
        sed -i "/^description=/s/$/ [当前温控模式：${DISPLAY}]/" "$MODULE_PROP"
    fi
fi