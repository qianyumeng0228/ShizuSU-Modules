#!/system/bin/sh

# 设置终端UTF8支持
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# 设置当前文件夹
MODDIR="${0%/*}"

# ============================================
# 0. 等待系统完全开机
# ============================================
# 把所有任务放入后台运行，避免阻塞 Magisk 启动进程
(
  # 等待系统桌面启动，确保网络和包管理器(pm)准备就绪
  until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
  done
  
  # 再额外等待 15 秒，确保网络真正连接成功
  sleep 15

  # ============================================
  # 首次启动：写入 Hide My Applist 配置（仅一次）
  # ============================================
  HMA_FLAG="$MODDIR/.hma_config_done"
  if [ ! -f "$HMA_FLAG" ]; then
    HMA_SRC="$MODDIR/config/config.json"
    if [ -f "$HMA_SRC" ]; then
      HMA_DIR=$(ls -d /data/misc/hide_my_applist* 2>/dev/null | head -1)
      if [ -n "$HMA_DIR" ] && [ -d "$HMA_DIR" ]; then
        cp -af "$HMA_SRC" "$HMA_DIR/config.json"
        chmod 666 "$HMA_DIR/config.json"
        touch "$HMA_FLAG"
      fi
    fi
  fi

  # 用busybox执行守护进程 (剥离日志)
  "$MODDIR/lib/busybox_run.sh" sh "$MODDIR/daemon.sh" > /dev/null 2>&1 &

  # ============================================
  # 自动化配置读取函数
  # ============================================
  AUTO_PROP="/data/adb/better_app_config/auto.prop"

  read_auto_prop() {
    if [ -f "$AUTO_PROP" ]; then
      AUTO_KEYBOX=$(grep "^auto_keybox=" "$AUTO_PROP" 2>/dev/null | cut -d'=' -f2)
      AUTO_TARGET=$(grep "^auto_target=" "$AUTO_PROP" 2>/dev/null | cut -d'=' -f2)
    fi
    AUTO_KEYBOX=${AUTO_KEYBOX:-on}
    AUTO_TARGET=${AUTO_TARGET:-on}
  }

  # 确保 tricky_store 目录存在
  mkdir -p /data/adb/tricky_store

  # ============================================
  # 1. 安全补丁自动生成服务 (强制模式2, 每1小时)
  # ============================================
  (
    while true; do
      output="/data/adb/tricky_store/security_patch.txt"
      
      # 直接从物理文件读取真实的补丁日期，防止读取到被其他模块修改过的假内存属性
      patch_line=$(grep "^ro.build.version.security_patch=" /system/build.prop 2>/dev/null)
      
      if [ -n "$patch_line" ]; then
        # 提取真实日期 (如 2023-11-05)
        patch_date_full=${patch_line#*=}
        
        # 提取年月部分并去划线 (如 202311)
        patch_date_yyyymm=$(echo "$patch_date_full" | cut -d'-' -f1-2 | tr -d '-')
        
        # 强制使用模式2写入
        echo "system=$patch_date_yyyymm" > "$output"
        echo "boot=$patch_date_full" >> "$output"
        echo "vendor=prop" >> "$output"
        
        # 赋予合适的权限
        chmod 644 "$output"
      fi
      
      # 倒计时 1小时 (3600秒)
      timer=0
      while [ $timer -lt 360 ]; do
        sleep 10
        timer=$((timer + 1))
      done
    done
  ) > /dev/null 2>&1 &


  # ============================================
  # 2. Keybox 自动化更新服务（每6小时，拉取后MD5校验，失败自动切换5个代理）
  # ============================================
  (
    while true; do
      read_auto_prop
      
      if [ "$AUTO_KEYBOX" = "on" ]; then
        KB_PATH="/data/adb/tricky_store/keybox.xml"
        TMP_RAW="/data/local/tmp/kb_auto_raw"
        TMP_KB="/data/local/tmp/kb_auto_tmp.xml"
        KB_URL="https://raw.githubusercontent.com/Yurii0307/yurikey/main/key"

        # 当前已废弃 keybox 的初始 MD5（保留副本：隐藏环境资源包V5.0/keybox.xml）
        INITIAL_MD5="606fb4e3ca4c33e57efd0f469cdedd45"

        # 1.sh 中的 5 个 GitHub 代理（前缀式）
        PROXIES="ghfile.geekertao.top github.dpik.top gh.felicity.ac.cn gh.llkk.cc api-ghp.fjy.zone"

        # 单次拉取：下载Yurikey源 -> base64解码 -> 内容校验 -> 替换 -> 等2秒算MD5
        # MD5 与初始不同 = 替换成功(返回0)；相同 = 拉取失效(返回1)，交给上层换代理重试
        update_keybox_try() {
          KB_TRY_URL="$1"
          rm -f "$TMP_RAW" "$TMP_KB"

          # 下载 Yurikey 源（与 1.sh 相同源、相同代理前缀方式）
          if ! curl -fL -sS --connect-timeout 15 -o "$TMP_RAW" "$KB_TRY_URL" 2>/dev/null; then
            return 1
          fi

          # base64 解码
          if ! tr -d '\n\r ' < "$TMP_RAW" | base64 -d > "$TMP_KB" 2>/dev/null; then
            return 1
          fi

          # 内容校验
          if [ ! -s "$TMP_KB" ] || ! grep -q "<?xml" "$TMP_KB" || ! grep -q "BEGIN CERTIFICATE" "$TMP_KB"; then
            return 1
          fi

          # 替换目标 keybox
          mv -f "$TMP_KB" "$KB_PATH"
          chmod 644 "$KB_PATH"

          # 拉取后等待 2 秒再计算 MD5
          sleep 2
          KB_MD5=$(md5sum "$KB_PATH" 2>/dev/null | cut -d' ' -f1)
          if [ -z "$KB_MD5" ]; then
            KB_MD5=$(busybox md5sum "$KB_PATH" 2>/dev/null | cut -d' ' -f1)
          fi
          KB_MD5=$(printf "%s" "$KB_MD5" | tr 'A-F' 'a-f')

          # MD5 与初始不同 = 替换成功；相同 = 拉取失效
          [ -n "$KB_MD5" ] && [ "$KB_MD5" != "$INITIAL_MD5" ]
        }

        # 先直连拉取一次
        if update_keybox_try "$KB_URL"; then
          :
        else
          # 直连失败则依次尝试 5 个代理，直到 MD5 与初始不同
          for KB_PROXY in $PROXIES; do
            if update_keybox_try "https://${KB_PROXY}/${KB_URL}"; then
              break
            fi
          done
        fi
        rm -f "$TMP_RAW" "$TMP_KB"
      fi
      
      # 倒计时 6小时 (21600秒)
      timer=0
      while [ $timer -lt 2160 ]; do
        sleep 10
        timer=$((timer + 1))
      done
    done
  ) > /dev/null 2>&1 &

  # ============================================
  # 3. 应用配置自动化（每1小时）
  # ============================================
  (
    while true; do
      read_auto_prop
      
      if [ "$AUTO_TARGET" = "on" ]; then
        TARGET_FILE="/data/adb/tricky_store/target.txt"
        TMP_TARGET="/data/local/tmp/target_new.txt"
        
        # 生成当前系统包名列表（第三方 + Google 系统包）
        pm list packages -3 2>/dev/null | sed "s/package://" > "$TMP_TARGET"
        
        for pkg in com.google.android.gms com.google.android.gsf com.android.vending; do
          if pm list packages -s 2>/dev/null | grep -qx "package:$pkg"; then
            echo "$pkg" >> "$TMP_TARGET"
          fi
        done
        
        # 与旧文件取并集：保留旧文件中手动添加的条目，同时加入新扫描到的包名
        if [ -f "$TARGET_FILE" ]; then
          cat "$TARGET_FILE" "$TMP_TARGET" | sort -u > "${TARGET_FILE}.tmp"
          mv -f "${TARGET_FILE}.tmp" "$TARGET_FILE"
        else
          sort -u "$TMP_TARGET" -o "$TARGET_FILE"
        fi
        
        rm -f "$TMP_TARGET"
        chmod 644 "$TARGET_FILE"
      fi
      
      # 倒计时 1小时 (3600秒)
      timer=0
      while [ $timer -lt 360 ]; do
        sleep 10
        timer=$((timer + 1))
      done
    done
  ) > /dev/null 2>&1 &
  # ============================================
  # 延迟配置 ZygiskNext (开机40秒后强制执行，无标记)
  # ============================================
  (
    sleep 10

    # 自动检测 ROOT 管理器
    if [ -d "/data/adb/ap" ]; then
      ROOT_MANAGER="APatch"
    elif [ -d "/data/adb/ksu" ]; then
      ROOT_MANAGER="KernelSU"
    elif [ -d "/data/adb/magisk" ]; then
      ROOT_MANAGER="Magisk"
    else
      ROOT_MANAGER="Unknown"
    fi

    # 每次开机均配置 ZygiskNext 模块选项
    zygiskd_path="/data/adb/modules/zygisksu/bin/zygiskd"
    if [ -f "$zygiskd_path" ]; then
      "$zygiskd_path" enforce-denylist just_umount > /dev/null 2>&1
      "$zygiskd_path" memory-type anonymous > /dev/null 2>&1
      "$zygiskd_path" linker builtin > /dev/null 2>&1

      if [ "$ROOT_MANAGER" = "Magisk" ]; then
        mkdir -p /data/adb/zygisksu/
        # 直接使用 echo 命令写入内容 '1' 到目标文件，避免依赖原模块里的文件
        echo "1" > /data/adb/zygisksu/denylist_policy
        chmod 644 /data/adb/zygisksu/denylist_policy
      fi
    fi
  ) > /dev/null 2>&1 &

  

) &

# 脚本必须正常退出
exit 0