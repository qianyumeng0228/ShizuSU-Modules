#!/system/bin/sh

# 设置终端UTF8支持
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8

AUTO_PROP="/data/adb/better_app_config/auto.prop"
mkdir -p "/data/adb/better_app_config"

# ============================================
# 1. 读取当前配置
# ============================================
if [ -f "$AUTO_PROP" ]; then
  AUTO_KEYBOX=$(grep "^auto_keybox=" "$AUTO_PROP" 2>/dev/null | cut -d'=' -f2)
  AUTO_TARGET=$(grep "^auto_target=" "$AUTO_PROP" 2>/dev/null | cut -d'=' -f2)
fi

AUTO_KEYBOX=${AUTO_KEYBOX:-on}
AUTO_TARGET=${AUTO_TARGET:-on}

# 状态转中文
to_cn() {
  case "$1" in
    on)  echo "开启" ;;
    off) echo "关闭" ;;
    *)   echo "未知" ;;
  esac
}

# ============================================
# 2. 音量键检测函数（带10秒超时）
# ============================================
confirm() {
  deadline=$(( $(date +%s) + 10 ))
  while [ "$(date +%s)" -lt "$deadline" ]; do
    events=$(/system/bin/timeout 1 /system/bin/getevent -l 2>/dev/null)
    case "$events" in
      *KEY_VOLUMEUP*)   return 0 ;;
      *KEY_VOLUMEDOWN*) return 1 ;;
    esac
  done
  return 1
}

# ============================================
# 3. 显示当前状态
# ============================================
echo "------------------------------------"
echo "         自动化服务配置菜单"
echo "------------------------------------"
echo ""
echo "  当前状态："
echo "  1. Keybox自动更新 (每6小时) : $(to_cn "$AUTO_KEYBOX")"
echo "  2. 应用配置自动更新 (每1小时) : $(to_cn "$AUTO_TARGET")"
echo "------------------------------------"
echo ""

# ============================================
# 4. 配置项 1：Keybox 自动更新
# ============================================
echo "  [1/2] Keybox自动更新"
echo "  音量上(+) : 开启"
echo "  音量下(-) : 关闭 (10秒无操作默认关闭)"
echo ""

if confirm; then
  AUTO_KEYBOX="on"
  echo "  Keybox自动更新 -> 开启"
else
  AUTO_KEYBOX="off"
  echo "  Keybox自动更新 -> 关闭"
fi

echo ""
echo "------------------------------------"
echo ""

# ============================================
# 5. 配置项 2：应用配置自动更新
# ============================================
echo "  [2/2] 应用配置自动更新"
echo "  音量上(+) : 开启"
echo "  音量下(-) : 关闭 (10秒无操作默认关闭)"
echo ""

if confirm; then
  AUTO_TARGET="on"
  echo "  应用配置自动更新 -> 开启"
else
  AUTO_TARGET="off"
  echo "  应用配置自动更新 -> 关闭"
fi

# ============================================
# 6. 保存配置（带写入验证）
# ============================================
echo ""
echo "------------------------------------"
echo ""
echo "  正在保存配置..."

if echo "auto_keybox=$AUTO_KEYBOX" > "$AUTO_PROP" && \
   echo "auto_target=$AUTO_TARGET" >> "$AUTO_PROP"; then
  chmod 644 "$AUTO_PROP"
  echo "  配置保存成功"
  echo ""
  echo "  最终状态："
  echo "  1. Keybox自动更新 : $(to_cn "$AUTO_KEYBOX")"
  echo "  2. 应用配置自动更新 : $(to_cn "$AUTO_TARGET")"
else
  echo "  配置保存失败！请检查磁盘空间和权限"
  exit 1
fi

echo ""
echo "------------------------------------"

exit 0
