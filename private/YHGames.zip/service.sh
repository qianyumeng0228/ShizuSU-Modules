#!/system/bin/sh

cd "/data/adb/modules/YHGames"
chmod 755 "YHGames"

echo "开始监控主守护进程..."

while true; do
    if pgrep -f "YHGames --yhgames" > /dev/null; then
        echo "守护进程 (YHGames --yhgames) 正在运行，监控完成"
        exit 0
    else
        echo "守护进程未运行，尝试启动..."
        ./YHGames --yhgames &
        echo "已启动，等待 5 秒后检查..."
        sleep 5
    fi
done
